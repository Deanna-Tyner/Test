import java.io.*;


public class Problem_1 {
	public static void main(String[] args) throws Exception{
		
		
		for(int x = 0; x < 9; x++)
		{
			try
			{
				System.out.println(x / x % 2);
			}
			catch(ArithmeticException T)
			{
				System.out.println(T.getMessage());
			}
			
		}
		
		
	}

}
