import java.util.*;
import java.lang.*;
import java.io.*;


public class Problem_2 {
	public static void main(String[] args) throws MyException{
		
		Scanner input = new Scanner(System.in);
		
		Integer a;
		float b;
		
		System.out.println("Please enter a integer: ");
		a = input.nextInt();
		
		System.out.println("Please enter a float: ");
		b = input.nextFloat();
		
			
		
		
		while(a > 0 && b > 0 ) 
		{
			
			
			try
			{
				System.out.println("Here is " + a + " and " + b + (a/b));
			}
			catch(ArithmeticException T)
			{
				System.out.println(T.getMessage());
			}
		
			
			System.out.println("Please enter a integer: ");
			a = input.nextInt();
			
			System.out.println("Please enter a float: ");
			b = input.nextFloat();
			
			
		}
		
		if(a == 0) 
			{
			throw new MyException("The integer you entered is zero");
			}
		else if(a < 0) 
			{
			throw new MyException("The integer you entered is a negative number");
			}
		else if(b == 0) 
			{
			throw new MyException("The float you entered is zero");
			}
		else if(b < 0)
			{
			throw new MyException("The float you entered is a negative number");
			}
		else if(a == 0 && b == 0)
		{
			throw new MyException("Both the integer and float is zero");
		}
		
		else if(a < 0 && b < 0)
		{
			throw new MyException("Both the integer and float is a negative number");
		}
		
			
			
		}
		
		
		
		
	}


